# UTS CS238 - Containerlab - Gathan Raihan Al Saleh

## 1. Deskripsi
Proyek ini merupakan eksperimen jaringan menggunakan Containerlab
untuk menguji routing, failover, protokol RIP dan OSPF, layanan TCP/UDP,
serta gangguan jaringan menggunakan Linux Traffic Control (tc/netem).

## 2. Topologi
Topologi terdiri dari:
- R-HQ
- R-BR1
- R-BR2
- R-DC
- PC-HQ1
- PC-HQ2
- PC-BR1
- PC-BR2
- APP-SRV
- DNS-SRV
- SW-HQ
- SW-BR1
- SW-BR2
- SW-DC

File topologi: topology.clab.yml

## 3. Teknologi
- Debian GNU/Linux melalui WSL
- Docker
- Containerlab
- FRRouting (FRR)
- Netshoot
- Linux iproute2
- ping, traceroute, netcat, tcpdump, iperf
- Traffic Control (tc/netem)

## 4. Struktur Direktori
- topology.clab.yml : definisi topologi
- configs/          : konfigurasi router
- evidence/         : log, hasil pengujian, dan packet capture
- collect.sh        : pengumpulan bukti
- failover.sh       : eksperimen failover
- gen-configs.sh    : pembuatan konfigurasi
- routing-mode.sh  : pengaturan mode routing
- static-failover.sh: eksperimen static failover
- summarize.sh      : ringkasan hasil eksperimen

## 5. Menjalankan Lab
Pastikan Docker dan Containerlab telah aktif.

Jalankan:
sudo containerlab deploy -t topology.clab.yml

## 6. Memeriksa Status
containerlab inspect -t topology.clab.yml

## 7. Menghentikan Lab
sudo containerlab destroy -t topology.clab.yml

## 8. Skenario Eksperimen
1. Static routing dan pengujian jalur alternatif.
2. Perbandingan routing RIP dan OSPF.
3. Pengujian koneksi TCP dan UDP.
4. Simulasi delay dan packet loss menggunakan tc/netem.
5. Investigasi gangguan dan pengujian pemulihan layanan.
6. Evaluasi risiko dan rekomendasi arsitektur jaringan.

## 9. Evidence
Seluruh bukti eksperimen disimpan di direktori evidence/.
Bukti mencakup hasil ping, perubahan interface, tabel routing,
neighbor OSPF, timeline failover, log layanan, dan packet capture.

## 10. Keterbatasan
Eksperimen dilakukan pada lingkungan virtual Containerlab,
bukan jaringan produksi. Hasil latensi, packet loss, dan failover
dipengaruhi oleh lingkungan host dan kondisi virtualisasi.
Hasil pengujian hanya mewakili kondisi saat eksperimen dilakukan.

## 11. Catatan Penggunaan AI
AI digunakan sebagai alat bantu untuk menyusun langkah eksperimen,
memeriksa konfigurasi, dan merapikan dokumentasi. Konfigurasi,
perintah, serta hasil pengujian tetap dijalankan dan diverifikasi
pada lingkungan Containerlab. Interpretasi akhir disesuaikan
dengan hasil pengukuran aktual.

## 12. Versi Lingkungan Pengujian
- Sistem operasi: Debian GNU/Linux 13 (Trixie)
- Lingkungan: WSL2
- Docker: 29.9.2
- Containerlab: 0.82.0
- FRRouting: 8.4.1
- Image router: frrouting/frr:v8.4.1
- Image PC/server/switch: nicolaka/netshoot:latest

## 13. Reproduksibilitas Eksperimen
Eksperimen dilakukan menggunakan topologi dan konfigurasi
yang tersedia pada direktori proyek ini.

Sebelum menjalankan ulang:
1. Pastikan Docker aktif.
2. Periksa file topology.clab.yml dan direktori configs/.
3. Deploy topologi menggunakan perintah pada bagian 5.
4. Jalankan skenario pengujian sesuai bagian 8.
5. Simpan hasil pengujian baru pada direktori evidence/.

Catatan: Hasil pengujian dapat berbeda bergantung pada kondisi
host, versi perangkat lunak, dan konfigurasi yang digunakan.

## 14. Status Konfigurasi dan Pemetaan Soal UTS

Konfigurasi routing aktif terakhir pada eksperimen adalah OSPF
area 0. Konfigurasi router yang disimpan pada configs/ digunakan
sebagai konfigurasi dasar saat lab dijalankan kembali.

Pemetaan eksperimen terhadap soal UTS:
1. Soal 1: Static routing, tabel routing, longest-prefix match,
   gangguan link, dan jalur alternatif.
2. Soal 2: Perbandingan RIP dan OSPF, neighbor, rute, dan failover.
3. Soal 3: Pengujian TCP, UDP, delay, dan packet loss.
4. Soal 4: Investigasi gangguan jaringan dan layanan serta
   pengujian pemulihan.
5. Soal 5: Evaluasi risiko, rekomendasi arsitektur, indikator
   keberhasilan, dan trade-off desain.

Catatan: Pengujian RIP dan static dilakukan sebagai skenario
terpisah. Jangan menganggap konfigurasi aktif terakhir OSPF
mewakili konfigurasi semua eksperimen sebelumnya.
